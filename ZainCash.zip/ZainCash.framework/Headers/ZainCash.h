//
//  ZainCash.h
//  ZainCash
//
//  Created by Ahmed Raad on 3/9/17.
//  Copyright © 2017 Ahmed Raad. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZainCash.
FOUNDATION_EXPORT double ZainCashVersionNumber;

//! Project version string for ZainCash.
FOUNDATION_EXPORT const unsigned char ZainCashVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZainCash/PublicHeader.h>


